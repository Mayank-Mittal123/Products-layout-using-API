document.addEventListener('DOMContentLoaded', function() {
    const tabs = document.querySelectorAll('.tab');
    const contents = document.querySelectorAll('.tab-content');

    tabs.forEach(tab => {
        tab.addEventListener('click', function() {
            const target = this.getAttribute('data-tab');

            tabs.forEach(t => {
                t.classList.remove('active');
                t.querySelector('.category-icon').style.display = 'none';
            });
            contents.forEach(c => c.classList.remove('active'));

            this.classList.add('active');
            this.querySelector('.category-icon').style.display = 'inline-block';
            document.getElementById(target).classList.add('active');
            
            const category = this.getAttribute('data-category');
            console.log(category);
            fetchProductData(category, target);
        });
    });

    async function fetchProductData(category, target) {
        try {
            const response = await fetch('https://cdn.shopify.com/s/files/1/0564/3685/0790/files/multiProduct.json');
            const data = await response.json();
            console.log('Fetched Data:', data);
            const categoryData = data.categories.find(c => c.category_name.toLowerCase() === category.toLowerCase());
            const filteredProducts = categoryData ? categoryData.category_products : [];
            console.log('Filtered Products:', filteredProducts);
            displayProducts(filteredProducts, target);
        } catch (error) {
            console.error('Error fetching product data:', error);
        }
    }

    function displayProducts(products, target) {
        const productContainer = document.querySelector(`#${target} .product-container`);
        productContainer.innerHTML = '';
        if (products.length === 0) {
            productContainer.innerHTML = '<p>No products found for this category.</p>';
            return;
        }
        products.forEach(product => {
            const productCard = document.createElement('div');
            productCard.classList.add('product');

            const imageBox = document.createElement('div');
            imageBox.classList.add('image-box');
            const img = document.createElement('img');
            img.src = product.image;
            imageBox.appendChild(img);

            if (product.badge_text) {
                const badge = document.createElement('div');
                badge.classList.add('product-badge');
                badge.textContent = product.badge_text;
                imageBox.appendChild(badge);
            }

            const productContent = document.createElement('div');
            productContent.classList.add('product-content');

            const titleCategory = document.createElement('div');
            titleCategory.classList.add('title-category');
            const title = document.createElement('h3');
            title.classList.add('product-title');
            title.textContent = product.title;
            const category = document.createElement('li');
            category.classList.add('product-category');
            category.textContent = product.vendor;
            titleCategory.appendChild(title);
            titleCategory.appendChild(category);

            const pricingContainer = document.createElement('div');
            pricingContainer.classList.add('pricing-container');
            const salePrice = document.createElement('div');
            salePrice.classList.add('sale-price');
            salePrice.textContent = `Rs. ${product.price}`;
            const originalPrice = document.createElement('del');
            originalPrice.classList.add('original-price');
            originalPrice.textContent = `Rs. ${product.compare_at_price}`;
            const discount = document.createElement('div');
            discount.classList.add('product-discount');
            const discountValue = ((product.compare_at_price - product.price) / product.compare_at_price) * 100;
            discount.textContent = `${discountValue.toFixed(0)}% Off`;
            pricingContainer.appendChild(salePrice);
            pricingContainer.appendChild(originalPrice);
            pricingContainer.appendChild(discount);

            const addToCartBtn = document.createElement('div');
            addToCartBtn.classList.add('add-to-cart-btn');
            addToCartBtn.textContent = 'Add To Cart';

            productContent.appendChild(titleCategory);
            productContent.appendChild(pricingContainer);
            productContent.appendChild(addToCartBtn);

            productCard.appendChild(imageBox);
            productCard.appendChild(productContent);

            productContainer.appendChild(productCard);
        });
    }

    // Initialize by showing the "Men" category products and setting the active tab
    const initialCategory = 'Men';
    fetchProductData(initialCategory, 'tab1');
    const initialTab = document.querySelector(`.tab[data-category="${initialCategory}"]`);
    if (initialTab) {
        initialTab.classList.add('active');
        initialTab.querySelector('.category-icon').style.display = 'inline-block';
        document.getElementById(initialTab.getAttribute('data-tab')).classList.add('active');
    }
});